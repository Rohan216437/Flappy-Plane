﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlappyOsama
{
    public partial class FlappyOsama : Form
    {

        int buildingspeed = 8;
        int gravity = 7;
        int score = 0;


        public FlappyOsama()
        {
            InitializeComponent();
        }

        private void gameTimerEvent(object sender, EventArgs e)
        {
            aeroplane.Top += gravity;
            buildingDown.Left -= buildingspeed;
            buildingUp.Left -= buildingspeed;
            scoreText.Text = "Score : " + score;

            if(buildingDown.Left < -150)
            {
                buildingDown.Left = 850;
                score++;
            }

            if (buildingUp.Left < -180)
            {
                buildingUp.Left = 620;
                score++;
            }

            if (aeroplane.Bounds.IntersectsWith(buildingDown.Bounds) ||
                aeroplane.Bounds.IntersectsWith(buildingUp.Bounds) ||
                aeroplane.Bounds.IntersectsWith(ground.Bounds)
                )
            {
                endGame();
            }
            if(aeroplane.Top < -25)
            {
                endGame();
            }

            if(score > 5)
            {
                buildingspeed = 13;
            }
        }

        private void FlappyOsama_Load(object sender, EventArgs e)
        {

        }

        private void gamekeyisDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Space)
            {
                gravity = -7;
            }
        }

        private void gamekeyisUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Space)
            {
                gravity = 7;
            }
        }

        private void endGame()
        {
            gameTime.Stop();
            scoreText.Text = " Game Over !!! ";
        }
    }
}
